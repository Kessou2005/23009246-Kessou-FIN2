# Étapes finales (dans l'ordre)

## Sur github.com (interface web, sans terminal)
1. Crée le dépôt PUBLIC `23009246-Kessou-FIN2` (coche « Add a README » : non, on a le nôtre).
2. « Add file » > « Upload files » : dépose le CONTENU du dossier (pas le dossier lui-même), avec ses sous-dossiers.
   Message du commit 1 : `Commit 1 : chargement et description des données`
3. Remplace dans le notebook : télécharge-le depuis Colab (Fichier > Télécharger > .ipynb) et dépose-le dans `notebooks/` sous le nom `projet_F16.ipynb`.
   Commit 2 : `Commit 2 : modèle, évaluation et figures`
4. Dépose `rapport/rapport.pdf` (Colab : Fichier > Imprimer > Enregistrer en PDF), la vidéo `video/demonstration.mp4` (ou mets le lien dans README.md), et complète `DECLARATION_IA.md` (ligne « Travail en binôme »).
   Commit 3 : `Commit 3 : rapport, vidéo, README et déclaration`
5. Tag : onglet « Releases » > « Create a new release » > tag `remise-finale` > « Publish release ».
6. Ouvre le dépôt en navigation privée pour vérifier qu'il est public et que tout s'affiche.
7. Soumets l'URL du dépôt et les liens demandés dans le formulaire : https://forms.gle/SmfW9kbcNbsz4Q8a7
